<?php
    //DATA CONNECTING

    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'lawyer_w';

    $con = mysqli_connect($host,$username,$password,$database);

    // $con = mysqli_connect('localhost','root','','umarz_p');

    // if($con){echo "Connected Successfully";}
    // else{echo "Connection Fail";}


?>