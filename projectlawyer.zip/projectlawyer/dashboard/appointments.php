<?php
include("header.php")
?>


<div class="card-body p-4">


                <h5 class="card-title fw-semibold mb-4">Appointment details </h5>
                <div class="table-responsive">
                  <table class="table text-nowrap mb-0 align-middle">
                    <thead class="text-dark fs-4">
                      <tr>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Client Name</h6>
                        </th>
                        <th class="-borderbottom-0">
                          <h6 class="fw-semibold mb-0">Client Email</h6>
                        </th>
                        <th class="-borderbottom-0">
                          <h6 class="fw-semibold mb-0">Client Phone.No</h6>
                        </th>
                        <th class="-borderbottom-0">
                          <h6 class="fw-semibold mb-0">Sevice Selected</h6>
                        </th>
                        <th class="-borderbottom-0">
                          <h6 class="fw-semibold mb-0">Appointment Date</h6>
                        </th>
                        <th class="-borderbottom-0">
                          <h6 class="fw-semibold mb-0">Appointment Time</h6>
                        </th>
                       
                       
                      </tr>
                    </thead>
                    <tbody>


                    <?php
                    $query = "SELECT appointment.appointment_id,appointment.customer_name,appointment.customer_email,appointment.customer_phone,appointment.a_date,appointment.a_time,lawyer_services.service_name as Services from appointment INNER JOIN lawyer_services on lawyer_services.id = appointment.lawyer_service";
                    $data = mysqli_query($con,$query);

                    while($row = mysqli_fetch_array($data)){
                        ?>

                        <tr style="text-transform: capitalize; color : black;">
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-0"><?php echo $row["customer_name"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["customer_email"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["customer_phone"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-0"><?php echo $row["Services"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["a_date"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["a_time"] ?></h6></td>
                        
                        
                      </tr> 

                        <?php
                    }
                    ?>


                                           
                    </tbody>
                  </table>
                </div>
              </div>















<?php
include("footer.php")
?>
