<?php
include("header.php")
?>



<div class="card-body p-4">


                <h5 class="card-title fw-semibold mb-4">Connect With Clients </h5>
                <div class="table-responsive">
                  <table class="table text-nowrap mb-0 align-middle">
                    <thead class="text-dark fs-4">
                      <tr>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Name</h6>
                        </th>
                        <th class="-borderbottom-0">
                          <h6 class="fw-semibold mb-0">Email</h6>
                        </th>
                        <th class="-borderbottom-0">
                          <h6 class="fw-semibold mb-0">Subject</h6>
                        </th>
                        <th class="-borderbottom-0">
                          <h6 class="fw-semibold mb-0">Message</h6>
                        </th>
                       
                       
                      </tr>
                    </thead>
                    <tbody>


                    <?php
                    $query = "select * from contact_us";
                    $data = mysqli_query($con,$query);

                    while($row = mysqli_fetch_array($data)){
                        ?>

                        <tr style="text-transform: capitalize; color : black;">
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-0"><?php echo $row["ur_name"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["ur_email"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["subject"] ?></h6></td>
                        
                        <td class="border-bottom-0"><textarea style="text-align: center;font-family: cursive;"  name="message" id="" cols="30" rows="5"><?php echo $row["message"] ?></textarea></td>
                      </tr> 

                        <?php
                    }
                    ?>


                                           
                    </tbody>
                  </table>
                </div>
              </div>








              <?php
include("footer.php")
?>







