<?php
include("header.php")
?>

<div class="card-body p-4">


                <h5 class="card-title fw-semibold mb-4">Service List  </h5>
                <div class="table-responsive">
                  <table class="table text-nowrap mb-0 align-middle">
                    <thead class="text-dark fs-4">
                      <tr>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Service Id</h6>
                        </th>
                        <th class="-borderbottom-0">
                          <h6 class="fw-semibold mb-0">Service Name</h6>
                        </th>
                       
                       
                      </tr>
                    </thead>
                    <tbody>


                    <?php
                    $query = "select * from lawyer_services";
                    $data = mysqli_query($con,$query);

                    while($row = mysqli_fetch_array($data)){
                        ?>

                        <tr>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-0"><?php echo $row["id"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["service_name"] ?></h6></td>
                      </tr> 
                        <?php
                    }
                    ?>


                                           
                    </tbody>
                  </table>
                </div>
              </div>








              <?php
include("footer.php")
?>