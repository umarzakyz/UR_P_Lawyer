<?php
include("header.php")
?>

<div class="card-body p-4">

                <a class="btn btn-primary" href="lawyer_register_here.php">Register here</a><br><br>
                <h5 class="card-title fw-semibold mb-4">Information  </h5>
                <div class="table-responsive">
                  <table class="table text-nowrap mb-0 align-middle">
                    <thead class="text-dark fs-4">
                      <tr>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">lawyer_id</h6>
                        </th>
                        <th class="-borderbottom-0">
                          <h6 class="fw-semibold mb-0">lawyer_name</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">lawyer_service</h6>
                        </th>
                        <th class="-borderbottom-0">
                          <h6 class="fw-semibold mb-0">lawyer_photo</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">lawyer_twitter</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">lawyer_facebook</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">lawyer_linkdin</h6>
                        </th>
                       
                      </tr>
                    </thead>
                    <tbody>


                    <?php
                    $query = "select * from lawyer_info";
                    $data = mysqli_query($con,$query);

                    while($row = mysqli_fetch_array($data)){
                        ?>

                        <tr>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-0"><?php echo $row["lawyer_id"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["lawyer_name"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["lawyer_service"] ?></h6></td>
                        <td class="border-bottom-0">
                              <img src="<?php echo $row["lawyer_photo"] ?>" width="150px" height="150px">
                    </td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["lawyer_twitter"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["lawyer_facebook"] ?></h6></td>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-1"><?php echo $row["lawyer_linkdin"] ?></h6></td>
                      </tr> 
                        <?php
                    }
                    ?>


                                           
                    </tbody>
                  </table>
                </div>
              </div>








              <?php
include("footer.php")
?>