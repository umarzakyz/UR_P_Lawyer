<?php
include("header.php")
?>


<form method="Post"  enctype="multipart/form-data">
<h5 class="card-title fw-semibold mb-4">Registering</h5>
              <div class="card">
                <div class="card-body">
                  <form>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Enter Your Name</label>
                      <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                      
                    </div>
                    
                     
                      <?php


$query = "select * from lawyer_services";
$data = mysqli_query($con,$query);
?>


                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label"> Select Your Service</label>
                      <select  class="form-control" name="services">
<?php
                      while($row = mysqli_fetch_array($data)){ 
?>

                            <option value="<?php echo $row["id"]  ?>"><?php echo $row["service_name"] ?></option>
                        
<?php
                        }
?>
                      </select>
                      
                    </div>


                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Enter Your Photo</label>
                      <input type="file" name="img" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                      
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Enter your Twitter</label>
                      <input type="text" name="twitter" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Enter your Facebook</label>
                      <input type="text" name="facebook" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                      </div>
                      <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Enter your Linkdin</label>
                      <input type="text" name="linkdin" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                      </div>
                   
                   
                    
                    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                  </form>
                </div>
              </div>
</form>


<?php        
if(isset($_POST["submit"])){
$pro_name = $_POST["name"];
$pro_serv = $_POST["services"];

//Image Uploading PHP code

$filename = $_FILES["img"]["name"];
$tempname = $_FILES["img"]["tmp_name"];
$folder = "assets/images/" . $filename;


$pro_twitter = $_POST["twitter"];
$pro_facebook = $_POST["facebook"];
$pro_linkdin = $_POST["linkdin"];

$query = "insert into lawyer_info values('','$pro_name','$pro_serv','$folder','$pro_twitter','$pro_facebook','$pro_linkdin')";

mysqli_query($con,$query);

if(move_uploaded_file($tempname, $folder)){
  header("location: lawyers_info.php");

}
}
?>

<?php
include("footer.php")
?>