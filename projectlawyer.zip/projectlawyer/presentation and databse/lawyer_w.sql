-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2024 at 03:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lawyer_w`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appointment_id` int(11) NOT NULL,
  `customer_name` tinytext DEFAULT NULL,
  `customer_email` tinytext DEFAULT NULL,
  `customer_phone` int(20) DEFAULT NULL,
  `lawyer_service` int(11) DEFAULT NULL,
  `a_date` date DEFAULT NULL,
  `a_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appointment_id`, `customer_name`, `customer_email`, `customer_phone`, `lawyer_service`, `a_date`, `a_time`) VALUES
(8, 'fahad', 'nikkammay3@gmail.com', 2147483647, 2, '0000-00-00', '03:54:00'),
(9, 'Kashif', 'Kashif347@gmail.com', 2147483647, 3, '0000-00-00', '03:54:00'),
(10, 'fatimaa', 'hgh@yahoo.com', 2147483647, 3, '0000-00-00', '02:51:00'),
(11, 'zoro', 'ramizshams22@gmail.com', 2323213, 2, '0000-00-00', '01:00:00'),
(12, 'zoro', 'ramizshams22@gmail.com', 2323213, 2, '0000-00-00', '01:00:00'),
(13, 'zoro', 'ramizshams22@gmail.com', 32424, 3, '0000-00-00', '02:51:00');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `ur_name` tinytext DEFAULT NULL,
  `ur_email` tinytext DEFAULT NULL,
  `subject` tinytext DEFAULT NULL,
  `message` varchar(179) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`ur_name`, `ur_email`, `subject`, `message`) VALUES
('umar', 'umar@gmail.com', 'marriage', 'I NEED A FAMILY LAWYER REGARDING MY MARRIAGE KINDLY CONTACT ME ASAP'),
('zain', 'ziana@yahoo.com', 'House Papers ', 'Need lawyer u');

-- --------------------------------------------------------

--
-- Table structure for table `lawyer_info`
--

CREATE TABLE `lawyer_info` (
  `lawyer_id` int(11) NOT NULL,
  `lawyer_name` tinytext DEFAULT NULL,
  `lawyer_service` int(11) DEFAULT NULL,
  `lawyer_photo` varchar(225) DEFAULT NULL,
  `lawyer_twitter` tinytext DEFAULT NULL,
  `lawyer_facebook` tinytext DEFAULT NULL,
  `lawyer_linkdin` tinytext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lawyer_info`
--

INSERT INTO `lawyer_info` (`lawyer_id`, `lawyer_name`, `lawyer_service`, `lawyer_photo`, `lawyer_twitter`, `lawyer_facebook`, `lawyer_linkdin`) VALUES
(2, 'Ramiz', 2, 'assets/images/dp.jpg', 'ramizshams67', 'ramiz22', 'rameez shams11'),
(3, 'Laiba', 4, 'assets/images/woman1.jpg', 'lebyy22', 'laiiiibaaaa31', 'laibababy');

-- --------------------------------------------------------

--
-- Table structure for table `lawyer_services`
--

CREATE TABLE `lawyer_services` (
  `id` int(11) NOT NULL,
  `service_name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lawyer_services`
--

INSERT INTO `lawyer_services` (`id`, `service_name`) VALUES
(1, 'Civil Law'),
(2, 'Criminal Law'),
(3, 'Business Law'),
(4, 'Family Law');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `lawyer_service` (`lawyer_service`);

--
-- Indexes for table `lawyer_info`
--
ALTER TABLE `lawyer_info`
  ADD PRIMARY KEY (`lawyer_id`),
  ADD KEY `lawyer_service` (`lawyer_service`);

--
-- Indexes for table `lawyer_services`
--
ALTER TABLE `lawyer_services`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `lawyer_info`
--
ALTER TABLE `lawyer_info`
  MODIFY `lawyer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lawyer_services`
--
ALTER TABLE `lawyer_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`lawyer_service`) REFERENCES `lawyer_services` (`id`);

--
-- Constraints for table `lawyer_info`
--
ALTER TABLE `lawyer_info`
  ADD CONSTRAINT `lawyer_info_ibfk_1` FOREIGN KEY (`lawyer_service`) REFERENCES `lawyer_services` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
